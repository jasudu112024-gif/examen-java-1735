/*
 * ============================================================
 * Archivo: LoteDAO.java
 * Propósito: contrato de acceso a datos de la tabla lotes (trazabilidad).
 * Conceptos clave: PATRÓN DAO (S18Demo01 UsuarioDAO) definido como
 *            interfaz (sesión 07 Notificable), List genérica (sesión 08),
 *            SQLException verificada (sesión 10).
 * Justificación: los servicios dependen de esta ABSTRACCIÓN y no de JDBC
 *            (Inversión de Dependencias, la "D" de SOLID). Cada DAO atiende
 *            UNA sola entidad (Responsabilidad Única) y expone solo los
 *            métodos que sus clientes usan (Segregación de Interfaces).
 *            Cada DAO ofrece el CRUD completo (insertar, buscar/listar,
 *            actualizar, eliminar) más sus consultas específicas.
 *            Convención: buscarPor... devuelve null si no hay resultado
 *            (como Grupo.obtener de S08Demo04); el llamador lo comprueba.
 * Visto en clase: cada concepto de los demos del curso se señala con un
 *   comentario "// Visto en clase" junto al código donde se usa.
 * ============================================================
 */
package com.carmotors.dao;

import com.carmotors.modelo.Lote;

import java.sql.SQLException;
import java.util.List;

// Visto en clase: interfaces e implements -> S07Demo04 Notificable (Sesión 07)
// Visto en clase: PATRÓN DAO (interfaz + implementación) -> S18Demo01 UsuarioDAO (Sesión 18)
public interface LoteDAO {
    // Visto en clase: try / catch / throw / throws -> S10Demo03ExcepcionesMain (Sesión 10)
    int insertar(Lote lote) throws SQLException;

    Lote buscarPorCodigo(String codigo) throws SQLException;

    // Visto en clase: List / ArrayList / genéricos <T> -> S08Demo01ArrayListMain y S08Demo03 Caja<T> (Sesión 08)
    List<Lote> listar() throws SQLException;

    List<Lote> listarPorRepuesto(int repuestoId) throws SQLException;


    /** Corrige proveedor y fecha de caducidad (código, repuesto y cantidad son trazabilidad fija). */
    int actualizar(Lote lote) throws SQLException;

    int eliminar(int id) throws SQLException;
}
